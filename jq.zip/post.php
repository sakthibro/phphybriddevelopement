<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>

<div data-role="page">
  <div data-role="header" data-theme='b'>
    <h1><?php echo $_POST['user']; ?></h1>
  </div>

  <div data-role="main" class="ui-content">
    <form method="post" action="post.php">
      <div class="ui-field-contain">
        <label for="info">username</label>
        <input     name="addinfo" id="info">


        <label for="info">username</label>
        <input     name="addinfo" id="info">
      
      </div>
      <input type="submit" data-theme='b' data-inline="true" value="Submit">
    </form> 
    
  </div>
    <div data-role="footer" data-theme='b'>
    <h1>Copyrighted & Published</h1>
  </div>
</div>

</body>
</html>
