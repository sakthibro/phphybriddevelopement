<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
<style>
#myPanel{background:rgb(55, 108, 179);color:white}

</style>

</style>
</head>
<body>
<div data-role="page" id="test1" data-theme="a">
<div data-role="header">
  <a href="#myPanel" data-transition="flow" data-rel="panel"class="ui-btn-active ui-btn-left ui-corner-all ui-icon-home ui-btn-icon-left">Home</a>
  <h1>Welcome To My Homepage</h1>
</div>


<div class="main" class="ui-content">

<div data-role="panel" id="myPanel">
  <h2>Panel Header..</h2>
  <p>Some text..</p>
</div>
<div data-role="popup" id="test">
  <h2>Panel Header..</h2>
  <p>Some text..</p>
</div>

<!-- alert-popup-->

<div data-role="popup" id="myPopupDialog">
  <div data-role="header"><h1>Header Text..</h1></div>
  <div data-role="main" class="ui-content"><p>Some text..</p><a href="#">some links..</a>
  <div data-role="footer"><h1>Footer Text..</h1></div>
</div>

<!-- listview-->
<ul data-role="listview">
  <li>
    <a href="#">
    <img src="beta.png">
    <h2>Google Chrome</h2>
    <p>Google Chrome is a free, open-source web browser. Released in 2008.</p>
    </a>
  </li>
</ul>


</div>


  <div data-role="footer" data-position="fixed">
    <div data-role="navbar">
      <ul>
        <li><a href="#test" data-rel="popup" data-position-to="window" data-transition="slideleft">Menu item 1</a></li>
        <li><a href="#" class="ui-btn-active ui-state-persist">Menu item 2</a></li>
        <li><a href="#">Menu item 3</a></li>
      </ul>
    </div>
    <h4 style="display:none;">Footer</h4>
  </div>


</div>

</body>
</html>
