
<?php

$out = array();

error_reporting(0);
$user=stripslashes($_POST['user']);
$pass=stripslashes($_POST['pwd']);
$branch=stripslashes($_POST['branch']);

$usern=mysql_real_escape_string($user);


$username=str_replace(" ","", $usern);

$password=str_replace(" ","", $pass);


//$db_con= mysqli_connect("localhost","root","","smartronics");
//$db_con= mysqli_connect("localhost","SERVTPOCC","SERVTPOCC@CC","smartronics");

 $db_con= mysqli_connect("localhost","SERVTPOCC","SERVTPO@CC","trail");


 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$user=stripslashes($_POST['us']);
$password = stripslashes($password);

$sql =" SELECT  * FROM `user` WHERE `username` = '$username' AND `password` = '$password'  ;";

$result=mysqli_query($db_con,$sql);

if (mysqli_num_rows($result)>0) 
{
    while($row = mysqli_fetch_assoc($result)) 
      
    {
     if  ("$username"  ==  $username && "$password"  == $password)
        
     {
      //session started

session_start();

       $user1=$row["username"];
       $pass1=$row["password"];
       $_SESSION['aid']=$row['aid'];
       $_SESSION['imgid']=$row['image_id'];

       $_SESSION['loc']=$row['branch'];
       $bran=$row['branch'];
       $e_bran=base64_encode($bran);
       $e_aid=base64_encode($_SESSION['aid']);

        $_SESSION['user']=$user1;
       
       $_SESSION[pass]=$pass1;
      
    $out['url']="test.php?aid=".$e_aid."&loc=".$e_bran;
    


    $out['res']=1;
     }
     else{


      $out['res']=0;


     }

    }

     
       
}
else{
  $out['no']=0;


}




echo json_encode($out);
mysqli_close($db_con);
  



   // Starting Session

// Closing db_con

?>